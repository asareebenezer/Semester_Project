#include <iostream>
#include <fstream>



using namespace std;


/* run this program using the console pauser or add your own getch, system("pause") or input loop */

void info(){
	string l_name,f_name,nationality,address,gender;
	
	cout<<"Enter your first name"<<endl;
	cin>>f_name;	
	cout<<"Enter your last name"<<endl;
	cin>>l_name;	
	cout<<"Enter your nationality"<<endl;
	cin>>nationality;	
	cout<<"Enter your gender"<<endl;
	cin>>gender;	
	cout<<"Enter your address"<<endl;
	cin>>address;	
	cout<<"VODAFONE CASH REGISTRATION SUCCESSFUL"<<endl;
	
	
}
int main() {
	
	int balance = 1000 ,default_pin = 1234 , acc_no;
	int pin, wrong_entries = 0, mobile_no,con_number, change_pin;
	int option = 0 , choice , till_no , con_till; 
	double tran_amount , with_amount, amount;	
	string user_name;
	
		cout << "Welcome To Vodafone Cash Centre"<<endl<<endl;
		cout << "1. Register account"<<endl; 
		cout << "2. Login " <<endl;
		cout << "3. Send Money"<<endl;
		cout << "4. Withdraw Cash"<< endl;
		cout << "5. Buy Airtime or Data"<<endl;
		cout << "6. Change your Pin"<<endl;
	    cout << "0. Exit"<<endl<<endl;
		cout << "Select your option"<<endl;
	do{
		cin >> option;	
		if(option == 1 ){
			info();	
			ofstream outFile("Reg_User.txt");	
			if (outFile.is_open() ){
				outFile<<"Your voda cash balance has been registered successfully"<<endl;
				outFile.close();
			}else{
				cout<<"Voda cash registration failed"<<endl;
			}		
		}		
		else if(option == 2 ){
			cout<<"Enter user name"<<endl;
			cin>>user_name;		
			cout<<"Enter your vcash pin"<<endl;
			cin>>pin;		
			if(pin != default_pin){
				for(int i =0 ; i<=3 ; i++);
				cout<<"Login failed , try again "<<endl;			
				cin>>pin;		
			}else{
				cout<<"Login successful"<<endl;
			}
		}	
    	else if(option == 3){
			cout<<"Enter receiver's mobile number" <<endl;
			cin>>mobile_no;	
			cout<<"Confirm receiver's mobile number"<<endl;
			cin>>con_number;	
			if(con_number != mobile_no){
				cout<<"Number mismatched "<<endl;
			}else if (con_number == mobile_no){
				cout<<"Enter amount to transfer"<<endl;
				cin>>tran_amount;		
				cout<<"Enter pin to confirm transaction"<<endl;
				cin>>pin;		
				if(pin != default_pin){
					for(int i= 0 ; i<=3 ; i++);
					cout<<"You have entered a wrong pin , try again"<<endl;
					cin>>pin;
				}else{
					cout<<"You have sent an amount of " << tran_amount << " to " << mobile_no <<endl<<endl;
					balance -= tran_amount;
					cout<<"Your remaining balance is " << balance;	
					ofstream outFile("balance. txt");	
					if(outFile.is_open()){
					  outFile<<"your remaining balance is " << balance;
					}
					outFile.close();
				}
			}
		}	
		else if(option == 4){
			cout<<"Withdraw amount from " <<endl;
			cout<<"1. Agent"<<endl;
			cout<<"2. Bank"<<endl;
			cin>>choice;	
			if(choice == 1 ){
				cout<<"Enter agent till number"<<endl;
				cin>>till_no;		
				cout<<"Re-enter till number"<<endl;
				cin>>con_till;	
				if(con_till == till_no){
					cout<<"Enter amount to withdraw " <<endl;
					cin>>with_amount;		
					if(with_amount >= balance){
						cout<<"insufficient balance , try again in a few minutes"<<endl;
					}else if(with_amount < balance ){
						cout<<"Enter pin to confirm withdrawal"<<endl;
						cin>>pin;		
						if(pin != default_pin){
							cout<<"You have enter a wrong pin , try again"<<endl;
							cin>>pin;
						}else{
							cout<<"You have successfully transferred an amount of " <<with_amount<<endl;
							balance-=with_amount;
							cout<<"Your remaining balance is " <<balance;
						}
					}
				}else{
					cout<<"till number mismatched " <<endl;
				}
			}else if (choice == 2){
				cout<<"Enter account number to proceed with withdrawal"<<endl;
				cin>>acc_no;
				
				cout<<"Enter amount to withdraw"<<endl;
				cin>>with_amount;
				
				cout<<"You have withdrawn an amount of " <<with_amount <<" from " <<acc_no<<endl;
			}	
		}	
		else if (option == 5 ){
			cout<<"1. Airtime"<<endl;
			cout<<"2. Data"<<endl;
			cin>>choice;		
			if(choice == 1 ){
				cout<<"By airtime for "<<endl;
				cout<<"1. Self"<<endl;
				cout<<"2. Others"<<endl;
				cin>>choice;		
				if(choice== 1){
					cout<<"Enter amount to buy"<<endl;
					cin>> amount;
					cout<<"Enter your pin"<<endl;
					cin>>pin;
					if(pin != default_pin){
						cout<<"Airtime purchase failed"<<endl;
					}else{
						cout<<"Airtime purchase successful"<<endl;
					}	
				}else if(choice == 2){
					cout<<"Enter receiver's mobile number" <<endl;
					cin>>mobile_no;
					cout<<"Confirm receiver's mobile number"<<endl;
					cin>>con_number;
					if(con_number == mobile_no){
						cout<<"Enter amount to transfer"<<endl;
						cin>>amount;
						cout<<"Enter pin to proceed with airtime purchase"<<endl;
						cin>>pin;
						if(pin==default_pin){
							cout<<"You have sent airtime of "<<amount<<" to " <<mobile_no<<endl;
						}
							
					}
					
					else{
						cout<<"number mismatched"<<endl;
					}
				}
			}
		}else if(option == 6){
         	
			cout << "Enter old PIN: "<< endl;
			cin >> change_pin;
			if (change_pin == default_pin){
			cout << "Enter new pin" << endl;
			cin >> change_pin;
			cout << "PIN changed successfully"<< endl;
		}else {
			cout << "Incorrect PIN. Please try again."<<endl;
			wrong_entries++;
		}
		if (wrong_entries == 3){
			cout << "Too many incorrect entries. Exiting program. "<<endl;
		
		}
		
     	}

     	

	
	}while(option != 0);
		
		

	
	return 0;
}
